package com.tnp.trader.center.core.provider.dao.mapper;


import com.tnp.trader.center.core.provider.dao.model.TnpUserRateConfig;
import java.util.List;

public interface TnpUserRateConfigMapper {

     public int insert(TnpUserRateConfig tnpUserRateConfig);

     public List<TnpUserRateConfig> listByCondition(TnpUserRateConfig tnpUserRateConfig);

     public List<TnpUserRateConfig> pageByCondition(TnpUserRateConfigWhereDto tnpUserRateConfigWhereDto);

     public int  countByCondition(TnpUserRateConfigWhereDto tnpUserRateConfigWhereDto);

     public int updateById(TnpUserRateConfig tnpUserRateConfig);

     public TnpUserRateConfig queryById(TnpUserRateConfig tnpUserRateConfig);

     public int deleteById(TnpUserRateConfig tnpUserRateConfig);

     public int updateByIndustryIdAndUserId(TnpUserRateConfig tnpUserRateConfig);

     public TnpUserRateConfig queryByIndustryIdAndUserId(TnpUserRateConfig tnpUserRateConfig);

     public int deleteByIndustryIdAndUserId(TnpUserRateConfig tnpUserRateConfig);

}