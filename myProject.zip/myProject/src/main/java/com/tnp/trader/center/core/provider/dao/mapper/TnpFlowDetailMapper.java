package com.tnp.trader.center.core.provider.dao.mapper;


import com.tnp.trader.center.core.provider.dao.model.TnpFlowDetail;
import java.util.List;

public interface TnpFlowDetailMapper {

     public int insert(TnpFlowDetail tnpFlowDetail);

     public List<TnpFlowDetail> listByCondition(TnpFlowDetail tnpFlowDetail);

     public List<TnpFlowDetail> pageByCondition(TnpFlowDetailWhereDto tnpFlowDetailWhereDto);

     public int  countByCondition(TnpFlowDetailWhereDto tnpFlowDetailWhereDto);

     public int updateById(TnpFlowDetail tnpFlowDetail);

     public TnpFlowDetail queryById(TnpFlowDetail tnpFlowDetail);

     public int deleteById(TnpFlowDetail tnpFlowDetail);

}