package com.tnp.trader.center.core.provider.dao.mapper;


import com.tnp.trader.center.core.provider.dao.model.TnpApplyFlow;
import java.util.List;

public interface TnpApplyFlowMapper {

     public int insert(TnpApplyFlow tnpApplyFlow);

     public List<TnpApplyFlow> listByCondition(TnpApplyFlow tnpApplyFlow);

     public List<TnpApplyFlow> pageByCondition(TnpApplyFlowWhereDto tnpApplyFlowWhereDto);

     public int  countByCondition(TnpApplyFlowWhereDto tnpApplyFlowWhereDto);

     public int updateById(TnpApplyFlow tnpApplyFlow);

     public TnpApplyFlow queryById(TnpApplyFlow tnpApplyFlow);

     public int deleteById(TnpApplyFlow tnpApplyFlow);

}