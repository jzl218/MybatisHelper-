package com.tnp.trader.center.core.provider.dao.model;


import java.util.Date;


public class TnpApplyFlow {

    /**
    *主键
    */
    private  String id;

    /**
    *引用类型
    */
    private  String refType;

    /**
    *表单id
    */
    private  String formId;

    /**
    *申请人id
    */
    private  String applyId;

    /**
    *申请人名称
    */
    private  String applyName;

    /**
    *申请时间
    */
    private  Date applyTime;

    /**
    *最后审核人id
    */
    private  String lastVerifyId;

    /**
    *最后审核人名称
    */
    private  String lastVerifyName;

    /**
    *最后审核时间
    */
    private  Date lastVerifyTime;

    /**
    *最后审核信息
    */
    private  String lastVerifyInfo;

    /**
    *状态  0-审核失败 1-审核成功 2-审核中 3-待复核
    */
    private  String status;

    /**
    *申请参数
    */
    private  String applyParam;

    /**
    *创建时间
    */
    private  Date createTime;

    /**
    *修改时间
    */
    private  Date modifyTime;

    /**
    *系统处理时间 0-未处理 1-已处理 2-待处理
    */
    private  String sysStatus;

    /**
    *标题
    */
    private  String applyTitle;

    /**
    *备注
    */
    private  String descn;

    /**
    *系统处理时间
    */
    private  Date sysHandleTime;

    public  String getId() {
     return id;    
   }

    public void  setId(String id) {
     this.id=id;    
    }

    public  String getRefType() {
     return refType;    
   }

    public void  setRefType(String refType) {
     this.refType=refType;    
    }

    public  String getFormId() {
     return formId;    
   }

    public void  setFormId(String formId) {
     this.formId=formId;    
    }

    public  String getApplyId() {
     return applyId;    
   }

    public void  setApplyId(String applyId) {
     this.applyId=applyId;    
    }

    public  String getApplyName() {
     return applyName;    
   }

    public void  setApplyName(String applyName) {
     this.applyName=applyName;    
    }

    public  Date getApplyTime() {
     return applyTime;    
   }

    public void  setApplyTime(Date applyTime) {
     this.applyTime=applyTime;    
    }

    public  String getLastVerifyId() {
     return lastVerifyId;    
   }

    public void  setLastVerifyId(String lastVerifyId) {
     this.lastVerifyId=lastVerifyId;    
    }

    public  String getLastVerifyName() {
     return lastVerifyName;    
   }

    public void  setLastVerifyName(String lastVerifyName) {
     this.lastVerifyName=lastVerifyName;    
    }

    public  Date getLastVerifyTime() {
     return lastVerifyTime;    
   }

    public void  setLastVerifyTime(Date lastVerifyTime) {
     this.lastVerifyTime=lastVerifyTime;    
    }

    public  String getLastVerifyInfo() {
     return lastVerifyInfo;    
   }

    public void  setLastVerifyInfo(String lastVerifyInfo) {
     this.lastVerifyInfo=lastVerifyInfo;    
    }

    public  String getStatus() {
     return status;    
   }

    public void  setStatus(String status) {
     this.status=status;    
    }

    public  String getApplyParam() {
     return applyParam;    
   }

    public void  setApplyParam(String applyParam) {
     this.applyParam=applyParam;    
    }

    public  Date getCreateTime() {
     return createTime;    
   }

    public void  setCreateTime(Date createTime) {
     this.createTime=createTime;    
    }

    public  Date getModifyTime() {
     return modifyTime;    
   }

    public void  setModifyTime(Date modifyTime) {
     this.modifyTime=modifyTime;    
    }

    public  String getSysStatus() {
     return sysStatus;    
   }

    public void  setSysStatus(String sysStatus) {
     this.sysStatus=sysStatus;    
    }

    public  String getApplyTitle() {
     return applyTitle;    
   }

    public void  setApplyTitle(String applyTitle) {
     this.applyTitle=applyTitle;    
    }

    public  String getDescn() {
     return descn;    
   }

    public void  setDescn(String descn) {
     this.descn=descn;    
    }

    public  Date getSysHandleTime() {
     return sysHandleTime;    
   }

    public void  setSysHandleTime(Date sysHandleTime) {
     this.sysHandleTime=sysHandleTime;    
    }

}