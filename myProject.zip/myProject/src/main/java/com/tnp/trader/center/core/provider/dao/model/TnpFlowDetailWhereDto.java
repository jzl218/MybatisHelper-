package com.tnp.trader.center.core.provider.dao.model;


import java.util.Date;
import com.lianlianpay.common.utils.db.PaginationQueryParam;


public class TnpFlowDetailWhereDto extends PaginationQueryParam {

    /**
    *主键
    */
    private  String id;

    /**
    *流程id
    */
    private  String flowId;

    /**
    *审核人id
    */
    private  String verifyId;

    /**
    *审核状态(0审核失败，1审核成功)
    */
    private  String status;

    /**
    *审核人名称
    */
    private  String verifyName;

    /**
    *审核时间
    */
    private  Date verifyTime;

    /**
    *审核描述
    */
    private  String verifyInfo;

    /**
    * 审核类型(1复核、2审核) 
    */
    private  String verifyType;

    /**
    *审核参数
    */
    private  String verifyParam;

    /**
    *创建时间
    */
    private  Date createTime;

    /**
    *修改时间
    */
    private  Date modifyTime;

    /**
    *开始时间
    */
    private  Date startDate;

    /**
    *结束时间
    */
    private  Date endDate;

    public  String getId() {
     return id;    
   }

    public void  setId(String id) {
     this.id=id;    
    }

    public  String getFlowId() {
     return flowId;    
   }

    public void  setFlowId(String flowId) {
     this.flowId=flowId;    
    }

    public  String getVerifyId() {
     return verifyId;    
   }

    public void  setVerifyId(String verifyId) {
     this.verifyId=verifyId;    
    }

    public  String getStatus() {
     return status;    
   }

    public void  setStatus(String status) {
     this.status=status;    
    }

    public  String getVerifyName() {
     return verifyName;    
   }

    public void  setVerifyName(String verifyName) {
     this.verifyName=verifyName;    
    }

    public  Date getVerifyTime() {
     return verifyTime;    
   }

    public void  setVerifyTime(Date verifyTime) {
     this.verifyTime=verifyTime;    
    }

    public  String getVerifyInfo() {
     return verifyInfo;    
   }

    public void  setVerifyInfo(String verifyInfo) {
     this.verifyInfo=verifyInfo;    
    }

    public  String getVerifyType() {
     return verifyType;    
   }

    public void  setVerifyType(String verifyType) {
     this.verifyType=verifyType;    
    }

    public  String getVerifyParam() {
     return verifyParam;    
   }

    public void  setVerifyParam(String verifyParam) {
     this.verifyParam=verifyParam;    
    }

    public  Date getCreateTime() {
     return createTime;    
   }

    public void  setCreateTime(Date createTime) {
     this.createTime=createTime;    
    }

    public  Date getModifyTime() {
     return modifyTime;    
   }

    public void  setModifyTime(Date modifyTime) {
     this.modifyTime=modifyTime;    
    }

    public  Date getStartDate() {
     return startDate;    
   }

    public void  setStartDate(Date startDate) {
     this.startDate=startDate;    
    }

    public  Date getEndDate() {
     return endDate;    
   }

    public void  setEndDate(Date endDate) {
     this.endDate=endDate;    
    }

}