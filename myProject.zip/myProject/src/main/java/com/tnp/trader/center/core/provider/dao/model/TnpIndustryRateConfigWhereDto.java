package com.tnp.trader.center.core.provider.dao.model;


import java.util.Date;
import com.lianlianpay.common.utils.db.PaginationQueryParam;


public class TnpIndustryRateConfigWhereDto extends PaginationQueryParam {

    /**
    *行业名称
    */
    private  String industryName;

    /**
    *行业编码
    */
    private  String industryId;

    /**
    *费率
    */
    private  String rate;

    /**
    *担保日期
    */
    private  Integer guaranteeDays;

    /**
    *封顶服务费
    */
    private  Long maxServiceFee;

    /**
    *保底服务费
    */
    private  Long minServiceFee;

    /**
    *创建时间
    */
    private  Date createTime;

    /**
    *更新时间
    */
    private  Date modifyTime;

    /**
    *生效开始时间
    */
    private  Date beginTime;

    /**
    *生效结束时间
    */
    private  Date endTime;

    /**
    *开始时间
    */
    private  Date startDate;

    /**
    *结束时间
    */
    private  Date endDate;

    public  String getIndustryName() {
     return industryName;    
   }

    public void  setIndustryName(String industryName) {
     this.industryName=industryName;    
    }

    public  String getIndustryId() {
     return industryId;    
   }

    public void  setIndustryId(String industryId) {
     this.industryId=industryId;    
    }

    public  String getRate() {
     return rate;    
   }

    public void  setRate(String rate) {
     this.rate=rate;    
    }

    public  Integer getGuaranteeDays() {
     return guaranteeDays;    
   }

    public void  setGuaranteeDays(Integer guaranteeDays) {
     this.guaranteeDays=guaranteeDays;    
    }

    public  Long getMaxServiceFee() {
     return maxServiceFee;    
   }

    public void  setMaxServiceFee(Long maxServiceFee) {
     this.maxServiceFee=maxServiceFee;    
    }

    public  Long getMinServiceFee() {
     return minServiceFee;    
   }

    public void  setMinServiceFee(Long minServiceFee) {
     this.minServiceFee=minServiceFee;    
    }

    public  Date getCreateTime() {
     return createTime;    
   }

    public void  setCreateTime(Date createTime) {
     this.createTime=createTime;    
    }

    public  Date getModifyTime() {
     return modifyTime;    
   }

    public void  setModifyTime(Date modifyTime) {
     this.modifyTime=modifyTime;    
    }

    public  Date getBeginTime() {
     return beginTime;    
   }

    public void  setBeginTime(Date beginTime) {
     this.beginTime=beginTime;    
    }

    public  Date getEndTime() {
     return endTime;    
   }

    public void  setEndTime(Date endTime) {
     this.endTime=endTime;    
    }

    public  Date getStartDate() {
     return startDate;    
   }

    public void  setStartDate(Date startDate) {
     this.startDate=startDate;    
    }

    public  Date getEndDate() {
     return endDate;    
   }

    public void  setEndDate(Date endDate) {
     this.endDate=endDate;    
    }

}