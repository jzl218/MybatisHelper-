package com.tnp.trader.center.core.provider.dao.mapper;


import com.tnp.trader.center.core.provider.dao.model.TnpIndustryRateConfig;
import java.util.List;

public interface TnpIndustryRateConfigMapper {

     public int insert(TnpIndustryRateConfig tnpIndustryRateConfig);

     public List<TnpIndustryRateConfig> listByCondition(TnpIndustryRateConfig tnpIndustryRateConfig);

     public List<TnpIndustryRateConfig> pageByCondition(TnpIndustryRateConfigWhereDto tnpIndustryRateConfigWhereDto);

     public int  countByCondition(TnpIndustryRateConfigWhereDto tnpIndustryRateConfigWhereDto);

     public int updateByIndustryId(TnpIndustryRateConfig tnpIndustryRateConfig);

     public TnpIndustryRateConfig queryByIndustryId(TnpIndustryRateConfig tnpIndustryRateConfig);

     public int deleteByIndustryId(TnpIndustryRateConfig tnpIndustryRateConfig);

}